var classcom_1_1flurry_1_1android_1_1tumblr_1_1Post =
[
    [ "setAndroidDeeplink", "classcom_1_1flurry_1_1android_1_1tumblr_1_1Post.html#a19b032a5eb6e198804258e7c9e7c18de", null ],
    [ "setIOSDeepLink", "classcom_1_1flurry_1_1android_1_1tumblr_1_1Post.html#ab6ac7cd61f9eb6ea4719ab915fc8efd3", null ],
    [ "setPostListener", "classcom_1_1flurry_1_1android_1_1tumblr_1_1Post.html#a7847abe6b563843d45210ca40a01d392", null ],
    [ "setWebLink", "classcom_1_1flurry_1_1android_1_1tumblr_1_1Post.html#a48d04826ce337dccea3377866b7af50c", null ]
];