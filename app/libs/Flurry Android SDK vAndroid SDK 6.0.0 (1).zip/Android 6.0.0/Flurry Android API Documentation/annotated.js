var annotated =
[
    [ "com", null, [
      [ "flurry", null, [
        [ "android", null, [
          [ "ads", null, [
            [ "FlurryAdNativeAsset", "classcom_1_1flurry_1_1android_1_1ads_1_1FlurryAdNativeAsset.html", "classcom_1_1flurry_1_1android_1_1ads_1_1FlurryAdNativeAsset" ],
            [ "FlurryAdNativeListener", "interfacecom_1_1flurry_1_1android_1_1ads_1_1FlurryAdNativeListener.html", "interfacecom_1_1flurry_1_1android_1_1ads_1_1FlurryAdNativeListener" ],
            [ "FlurryAdNativeAssetType", "enumcom_1_1flurry_1_1android_1_1ads_1_1FlurryAdNativeAssetType.html", null ],
            [ "FlurryGender", "enumcom_1_1flurry_1_1android_1_1ads_1_1FlurryGender.html", null ],
            [ "FlurryAdInterstitial", "classcom_1_1flurry_1_1android_1_1ads_1_1FlurryAdInterstitial.html", "classcom_1_1flurry_1_1android_1_1ads_1_1FlurryAdInterstitial" ],
            [ "FlurryAdInterstitialListener", "interfacecom_1_1flurry_1_1android_1_1ads_1_1FlurryAdInterstitialListener.html", "interfacecom_1_1flurry_1_1android_1_1ads_1_1FlurryAdInterstitialListener" ],
            [ "FlurryAdBanner", "classcom_1_1flurry_1_1android_1_1ads_1_1FlurryAdBanner.html", "classcom_1_1flurry_1_1android_1_1ads_1_1FlurryAdBanner" ],
            [ "FlurryAdErrorType", "enumcom_1_1flurry_1_1android_1_1ads_1_1FlurryAdErrorType.html", null ],
            [ "FlurryAdNativeStyle", "classcom_1_1flurry_1_1android_1_1ads_1_1FlurryAdNativeStyle.html", null ],
            [ "FlurryAdNative", "classcom_1_1flurry_1_1android_1_1ads_1_1FlurryAdNative.html", "classcom_1_1flurry_1_1android_1_1ads_1_1FlurryAdNative" ],
            [ "FlurryAdBannerListener", "interfacecom_1_1flurry_1_1android_1_1ads_1_1FlurryAdBannerListener.html", "interfacecom_1_1flurry_1_1android_1_1ads_1_1FlurryAdBannerListener" ],
            [ "FlurryAdTargeting", "classcom_1_1flurry_1_1android_1_1ads_1_1FlurryAdTargeting.html", "classcom_1_1flurry_1_1android_1_1ads_1_1FlurryAdTargeting" ]
          ] ],
          [ "tumblr", null, [
            [ "PhotoPost", "classcom_1_1flurry_1_1android_1_1tumblr_1_1PhotoPost.html", "classcom_1_1flurry_1_1android_1_1tumblr_1_1PhotoPost" ],
            [ "PostListener", "interfacecom_1_1flurry_1_1android_1_1tumblr_1_1PostListener.html", "interfacecom_1_1flurry_1_1android_1_1tumblr_1_1PostListener" ],
            [ "TextPost", "classcom_1_1flurry_1_1android_1_1tumblr_1_1TextPost.html", "classcom_1_1flurry_1_1android_1_1tumblr_1_1TextPost" ],
            [ "Post", "classcom_1_1flurry_1_1android_1_1tumblr_1_1Post.html", "classcom_1_1flurry_1_1android_1_1tumblr_1_1Post" ],
            [ "TumblrShare", "classcom_1_1flurry_1_1android_1_1tumblr_1_1TumblrShare.html", null ]
          ] ],
          [ "Constants", "interfacecom_1_1flurry_1_1android_1_1Constants.html", null ],
          [ "FlurryAdSize", "enumcom_1_1flurry_1_1android_1_1FlurryAdSize.html", null ],
          [ "FlurryAds", "classcom_1_1flurry_1_1android_1_1FlurryAds.html", null ],
          [ "FlurryAgent", "classcom_1_1flurry_1_1android_1_1FlurryAgent.html", null ],
          [ "FlurryAgentListener", "interfacecom_1_1flurry_1_1android_1_1FlurryAgentListener.html", "interfacecom_1_1flurry_1_1android_1_1FlurryAgentListener" ],
          [ "FlurrySyndicationEventName", "enumcom_1_1flurry_1_1android_1_1FlurrySyndicationEventName.html", null ]
        ] ]
      ] ]
    ] ]
];