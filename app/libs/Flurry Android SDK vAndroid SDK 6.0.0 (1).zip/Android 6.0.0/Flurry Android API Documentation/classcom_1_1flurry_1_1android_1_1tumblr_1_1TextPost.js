var classcom_1_1flurry_1_1android_1_1tumblr_1_1TextPost =
[
    [ "TextPost", "classcom_1_1flurry_1_1android_1_1tumblr_1_1TextPost.html#a2e893484e0a29cff37084cc548fd5856", null ],
    [ "setTitle", "classcom_1_1flurry_1_1android_1_1tumblr_1_1TextPost.html#aa5efcca60e111de66c866aec4afeb920", null ]
];